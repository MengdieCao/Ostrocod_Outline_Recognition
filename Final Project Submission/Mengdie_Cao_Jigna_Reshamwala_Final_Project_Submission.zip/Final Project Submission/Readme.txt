To run the project. Open OstracodRecognitionfFinal.html in any browser.
To load file in the background, click on Choose File button.
Select the .jpg file. Make sure that the file is placed in the same folder as "OstracodRecognitionfFinal.html", Also the jpg names files should not have spaces.
Once the image is loaded in the background. Follow instructions on the top left corner. After drawing the outline of the ostracod, press "Process Outline" button. The output of the recognition will be displayed on the screen.